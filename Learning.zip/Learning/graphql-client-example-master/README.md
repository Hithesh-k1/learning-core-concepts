# graphql-client-example
This project is an example for my blog article:

[Implementing CRUD in web application using React and GraphQL](https://codetain.com/blog/implementing-crud-in-web-application-using-react-and-graphql)

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.
