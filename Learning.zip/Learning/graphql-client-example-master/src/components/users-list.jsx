import React, { useState } from "react";
import styled from "styled-components";
import { useQuery } from "@apollo/react-hooks";
import { gql } from "apollo-boost";

import UserDetails from "./user-details";

const USERS_QUERY = gql`
  {
    characters {
      results {
        id
        name
        status
        image
      }
    }
  }
`;

const StyledCardWrapper = styled.div`
box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
transition: 0.3s;
`;

const StyledContainer = styled.div`
display:flex;
flex-wrap: wrap;
width:30%;
`;

const StyledImage=styled.img`
width: 100%;

`

const UsersList = () => {
  const { loading, error, data } = useQuery(USERS_QUERY);
  const [userId, setUserId] = useState(null);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error...</p>;

  return (
    <StyledContainer>
      <h2>Users</h2>
      {data.characters.results.map(({ id, name, status,image }) => (
        <StyledCardWrapper key={id}>
            <StyledImage src={image} alt="Avatar" />
            <div class="container">
              <h4>
                {name}
              </h4>
              <p>{status}</p>
            </div>
        </StyledCardWrapper>
      ))}
      {userId && <UserDetails id={userId}></UserDetails>}
    </StyledContainer>
  );
};

export default UsersList;
