import * as ReactDOM from 'react-dom';
import App from './App';

// Create a root.
const root = ReactDOM.createRoot(document.getElementById('root'));


// Initial render: Render an element to the root.
root.render(<App/>);