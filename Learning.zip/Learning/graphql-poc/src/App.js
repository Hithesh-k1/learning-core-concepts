import React from "react";
import UsersList from "./UserList";
import ApolloClient from "apollo-boost";
import { ApolloProvider } from "@apollo/react-hooks";

const client = new ApolloClient({
  uri: "https://rickandmortyapi.com/graphql",
});

function App() {
  return (
    <>
      <React.StrictMode>
        <ApolloProvider client={client}>
          <>
          
          <h1>Simple GraphQL client</h1>
          <UsersList />
          </>
        </ApolloProvider>
      </React.StrictMode>
    </>
  );
}

export default App;
