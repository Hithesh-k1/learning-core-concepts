import React from "react";
import "./modal.css";
function Modal({ isShow, setIsShow }) {
  return (
    <div className="modal">
      <button onClick={()=>setIsShow(false)}>close</button>
      Modal
    </div>
  );
}

export default Modal;
