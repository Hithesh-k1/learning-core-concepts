import { useState } from "react";
import "./App.css";
import Modal from "./Modal";

function App() {
  const [isShow, setIsShow] = useState(false);
  return (
    <div className="App">
      <button onClick={() => setIsShow(true)}>SHOW MODAL</button>
      {isShow && <Modal isShow={isShow} setIsShow={setIsShow} />}

    
    </div>
  );
}

export default App;
