# GraphQL-ApolloClient-Template

## Youtube Tutorial
[YOUTUBE VIDEO](https://www.youtube.com/watch?v=Dr2dDWzThK8)


## Stack
FrontEnd:
- React
- Apollo Client
- GraphQL

BackEnd:
- NodeJS
- ExpressJS
- GraphQL
- Express-GraphQL
