import UsersList from "./Component/UsersList";
import "./App.css";

function App() {
  return <UsersList />;
}

export default App;
