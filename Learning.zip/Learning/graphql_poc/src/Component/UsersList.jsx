import React from "react";
import { useQuery } from "@apollo/react-hooks";
import { gql } from "apollo-boost";

const USERS_QUERY = gql`
  {
  characters {
    results {
      id
      name
      status
      image
      species
    }
  }
}
`;

const UsersList = () => {
  const { loading, error, data } = useQuery(USERS_QUERY);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error...</p>;

  return (
    <ul>
      {data.users.map(({ id, firstname, lastname }) => (
        <li key={id}>
          {firstname} {lastname}
        </li>
      ))}
    </ul>
  );
};

export default UsersList;
